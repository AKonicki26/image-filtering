import './App.css'
import ImageTransformer from './components/ImageTransformer/ImageTransformer'

function App() {
    return (
        <div className="app">
            <ImageTransformer />
        </div>
    )
}

export default App